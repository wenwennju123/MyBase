#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 *
 * @author Leo
 * @version 1.0
 * @className ${NAME}
 * @since 1.0
 **/
public interface ${NAME} {
}
