package org.jeecg.config.vo;

import javax.print.DocFlavor;

/**
 *
 * @author: scott
 * @date: 2022年04月18日 20:35
 */
public class Path {
    private String upload;
    private String webapp;

    public String getUpload() {
        return upload;
    }

    public void setUpload(String upload) {
        this.upload = upload;
    }

    public String getWebapp() {
        return webapp;
    }

    public void setWebapp(String webapp) {
        this.webapp = webapp;
    }
}
